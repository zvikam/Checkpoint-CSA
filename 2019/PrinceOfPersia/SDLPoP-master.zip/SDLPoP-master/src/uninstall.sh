#! /bin/bash

rm /usr/share/applications/SDLPoP.desktop

